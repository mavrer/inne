#include "wektor.h"

Wektor::Wektor() : vx(0), vy(0) {}

void Wektor::Set_vx(double v) {vx = v;}

void Wektor::Set_vy(double v) {vy = v;}

double Wektor::Get_vx() const {return vx;}

double Wektor::Get_vy() const {return vy;}
