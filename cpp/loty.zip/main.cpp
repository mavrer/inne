#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "generator.h"

using namespace std;

int main() {
    ifstream in("in.txt");
    if (!in) {
        cerr << "Brak pliku in.txt\n";
        return 1;
    }

    double xd, xg, yd, yg;
    int Nx, Ny;
    in >> xd >> xg >> Nx >> yd >> yg >> Ny;

    Generator g(xd, xg, Nx, yd, yg, Ny);
    g.generuj_siatke(80, 500);

    ifstream tr("track.txt");
    if (!tr) {
        cerr << "Brak pliku track.txt\n";
        return 1;
    }

    vector<string> etykiety;
    vector<pair<double, double>> wsp;
    string et;
    double x, y;
    while (tr >> et >> x >> y) {
        etykiety.push_back(et);
        wsp.emplace_back(x, y);
    }

    double V_samolotu = 900.0;

    g.generuj_plan_lotu(etykiety, wsp, V_samolotu, "plan.txt");
    g.generuj_trajectorie(etykiety, wsp, V_samolotu, "trajectory.txt");

    return 0;
}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.