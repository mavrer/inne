#ifndef GENERATOR_H
#define GENERATOR_H

#include <vector>
#include <string>
#include <utility>

using namespace std;

class Generator {
private:
    double xd, xg, yd, yg;
    int Nx, Ny;
    vector<vector<double>> vx_siatka;
    vector<vector<double>> vy_siatka;

    double kat(double dx, double dy);
    double dlugosc_wektora(double vx, double vy);

public:
    Generator(double xd_, double xg_, int Nx_, double yd_, double yg_, int Ny_);
    void generuj_siatke(double A, double B);
    void generuj_plan_lotu(const vector<string>& etykiety,
                           const vector<pair<double, double>>& wsp,
                           double V_samolotu,
                           const string& wyjscie);
    void generuj_trajectorie(const vector<string>& etykiety,
                             const vector<pair<double, double>>& wsp,
                             double V_samolotu,
                             const string& wyjscie);
};

#endif
