#include "generator.h"
#include <cmath>
#include <fstream>
#include <iostream>

using namespace std;

Generator::Generator(double xd_, double xg_, int Nx_, double yd_, double yg_, int Ny_)
    : xd(xd_), xg(xg_), Nx(Nx_), yd(yd_), yg(yg_), Ny(Ny_) {
    vx_siatka.resize(Ny, vector<double>(Nx));
    vy_siatka.resize(Ny, vector<double>(Nx));
}

double Generator::kat(double dx, double dy) {
    return atan2(dy, dx);
}

double Generator::dlugosc_wektora(double vx, double vy) {
    return sqrt(vx * vx + vy * vy);
}

void Generator::generuj_siatke(double A, double B) {
    double dx = (xg - xd) / (Nx - 1);
    double dy = (yg - yd) / (Ny - 1);

    for (int j = 0; j < Ny; ++j) {
        for (int i = 0; i < Nx; ++i) {
            double x = xd + i * dx;
            double y = yd + j * dy;

            double r = sqrt((x - B) * (x - B) + (y - B) * (y - B));
            double v = A * (exp(1.0) / B) * r * exp(-r / B);
            double alpha = atan2(x - B, -(y - B));
            vx_siatka[j][i] = v * cos(alpha);
            vy_siatka[j][i] = v * sin(alpha);
        }
    }
}

void Generator::generuj_plan_lotu(const vector<string>& etykiety,
                                  const vector<pair<double, double>>& wsp,
                                  double V_samolotu,
                                  const string& wyjscie) {
    ofstream out(wyjscie);
    if (!out) {
        cerr << "Błąd zapisu do pliku " << wyjscie << endl;
        return;
    }

    double czas = 0;

    for (size_t i = 0; i < wsp.size(); ++i) {
        if (i > 0) {
            double dx = wsp[i].first - wsp[i - 1].first;
            double dy = wsp[i].second - wsp[i - 1].second;
            double d = sqrt(dx * dx + dy * dy);
            czas += d / V_samolotu * 60.0;
        }
        out << etykiety[i] << " " << wsp[i].first << " " << wsp[i].second << " " << czas << "\n";
    }
}

void Generator::generuj_trajectorie(const vector<string>& etykiety,
                                    const vector<pair<double,double>>& punkty,
                                    double V_samolotu,
                                    const string& nazwa_pliku) {
    ofstream outfile(nazwa_pliku);
    if (!outfile) {
        cerr << "Błąd otwarcia pliku: " << nazwa_pliku << endl;
        return;
    }

    double czas = 0.0;

    double dx_grid = (xg - xd) / (Nx - 1);
    double dy_grid = (yg - yd) / (Ny - 1);

    for (size_t i = 0; i < punkty.size() - 1; ++i) {
        double x_start = punkty[i].first;
        double y_start = punkty[i].second;
        double x_cel = punkty[i+1].first;
        double y_cel = punkty[i+1].second;

        double dx = x_cel - x_start;
        double dy = y_cel - y_start;
        double dystans = sqrt(dx * dx + dy * dy);

        double ux = dx / dystans;
        double uy = dy / dystans;

        double x_srodek = (x_start + x_cel) / 2.0;
        double y_srodek = (y_start + y_cel) / 2.0;

        int ix = (int)((x_srodek - xd) / dx_grid);
        int iy = (int)((y_srodek - yd) / dy_grid);

        ix = max(0, min(ix, Nx - 1));
        iy = max(0, min(iy, Ny - 1));

        double vx_wiatr = vx_siatka[iy][ix];
        double vy_wiatr = vy_siatka[iy][ix];

        double vx_samolotu = V_samolotu * ux;
        double vy_samolotu = V_samolotu * uy;

        double vx_2 = vx_samolotu + vx_wiatr;
        double vy_2 = vy_samolotu + vy_wiatr;

        double V_sam2 = sqrt(vx_2 * vx_2 + vy_2 * vy_2);

        double czas_przelotu = (dystans / V_sam2) * 60.0;
        czas += czas_przelotu;

        outfile << etykiety[i+1] << " " << x_cel << " " << y_cel << " " << czas << "\n";
    }

    outfile.close();
}
