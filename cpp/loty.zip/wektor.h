#ifndef WEKTOR_H
#define WEKTOR_H

class Wektor {
private:
    double vx;
    double vy;

public:
    Wektor();
    void Set_vx(double);
    void Set_vy(double);
    double Get_vx() const;
    double Get_vy() const;
};

#endif
